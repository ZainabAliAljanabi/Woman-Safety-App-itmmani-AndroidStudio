this is an app project for woman safety coded using java and xml on Android Studio 
